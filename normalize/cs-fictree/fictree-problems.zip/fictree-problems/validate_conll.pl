#!/usr/bin/perl
# Checks whether input is a valid CoNLL-like file.
# Copyright © 2013, 2014 Dan Zeman <zeman@ufal.mff.cuni.cz>
# License: GNU GPL

use utf8;
use open ':utf8';
binmode(STDIN, ':utf8');
binmode(STDOUT, ':utf8');
binmode(STDERR, ':utf8');

$ngloberr = 0;
$nglobsentences = 0;
$nglobtokens = 0;
$nglobcycles = 0;
$nglobcyclesentences = 0;
$iglobline = 0;
while(<>)
{
    $iglobline++;
    # Remove line break.
    s/\r?\n//;
    # Empty line => end of sentence => process sentence buffer.
    if($_ eq '')
    {
        $nglobsentences++;
        process_sentence(@buffer);
        @buffer = ();
    }
    elsif($_ =~ m/^\s*$/)
    {
        print STDERR ("WARNING: Line appears empty but in fact it contains ", length($_), " whitespace characters.\n");
        $ngloberr++;
    }
    else
    {
        push(@buffer, $_);
    }
}
if(scalar(@buffer)>0)
{
    print STDERR ("WARNING: Unprocessed non-empty buffer on end of input. Is the last sentence terminated by a blank line?\n");
    $ngloberr++;
}
printf STDERR ("TOTAL $nglobsentences sentences and $nglobtokens tokens (average %.2f tokens per sentence).\n", $nglobsentences ? $nglobtokens/$nglobsentences : 0);
printf STDERR ("TOTAL $nglobcycles cycles (%.2f %% tokens).\n", $nglobtokens ? $nglobcycles/$nglobtokens*100 : 0);
printf STDERR ("TOTAL $nglobcyclesentences sentences with cycles (%.2f %% sentences).\n", $nglobsentences ? $nglobcyclesentences/$nglobsentences*100 : 0);
if($ngloberr==0)
{
    print STDERR ("Check done. No problems found.\n");
}
else
{
    print STDERR ("Check done. Found $ngloberr problems.\n");
}



#------------------------------------------------------------------------------
# Check one sentence.
#------------------------------------------------------------------------------
sub process_sentence
{
    my @buffer = @_;
    # Global counter of sentences.
    $sentid++;
    my $n = scalar(@buffer);
    my $link = sprintf("sentence $sentid [head -%d | tail -%d]", $iglobline, $n+1);
    if($n==0)
    {
        print STDERR ("WARNING: $link: Empty sentence, i.e. more than one blank line between sentences.\n");
        $ngloberr++;
    }
    # Split every line to columns.
    my @matrix;
    my $ncol;
    my $iline = 0;
    foreach my $line (@buffer)
    {
        $iline++;
        my @xt = split(/\t/, $line);
        my @xs = split(/\s/, $line);
        my $nxt = scalar(@xt);
        my $nxs = scalar(@xs);
        if($nxt != $nxs)
        {
            print STDERR ("WARNING: $link $iline: Splitting line on tabs gives $nxt columns while splitting it on any space gives $nxs columns.\n");
            $ngloberr++;
        }
        # From now on, @xs will be used (just in case it differs from @xt).
        # The following is just a sanity check. We should never get inside the block, regardless the input data.
        if($nxs == 0)
        {
            print STDERR ("WARNING: $link $iline: Sentence-internal line is empty!\n");
            $ngloberr++;
        }
        if(!defined($ncol))
        {
            $ncol = $nxs;
        }
        elsif($nxs != $ncol)
        {
            print STDERR ("WARNING: $link $iline: This line has $nxs columns while the first line of the sentence has $ncol columns.\n");
            $ngloberr++;
        }
        push(@matrix, \@xs);
    }
    # Check the contents in more detail.
    my $maxnodeid = $#matrix+1;
    my $sentncycles = 0;
    for(my $i = 0; $i<=$#matrix; $i++)
    {
        # Meaning of columns may vary but column 0 should always contain the index (ID, ord) of the node.
        if($matrix[$i][0] !~ m/^\d+$/ || $matrix[$i][0] != $i+1)
        {
            print STDERR ("WARNING: $link $iline: The tokens in the sentence are not numbered continuously, starting at 1.\n");
            $ngloberr++;
        }
        # CoNLL 2006 columns: ID WORD LEMMA CPOS POS FEAT HEAD DEPREL PHEAD PDEPREL
        # => $column[6] should be either '_' or an index between 0 and the max ID in the sentence.
        if($matrix[$i][6] ne '_' && ($matrix[$i][6] !~ m/^\d+$/ || $matrix[$i][6] > $maxnodeid))
        {
            print STDERR ("WARNING: $link $iline: The HEAD reference $matrix[$i][6] is out of bounds (0..$maxnodeid).\n");
            $ngloberr++;
        }
        if(find_cycle(\@matrix, $matrix[$i][0]))
        {
            print STDERR ("WARNING: $link $iline: Cycle detected on the path from node $matrix[$i][0] to the root.\n");
            $ngloberr++;
            $nglobcycles++;
            $sentncycles++;
        }
    }
    $nglobcyclesentences++ if($sentncycles>0);
    $nglobtokens += $n;
}



#------------------------------------------------------------------------------
# Searches for cycles on the path from the current node to the root. Note that
# the current node may not cause a cycle but there might be a yet-undetected
# cycle further up the path. No node can be traversed twice.
#------------------------------------------------------------------------------
sub find_cycle
{
    # $matrix->[0] ... first line of the sentence => $matrix->[0][0] == 1
    my $matrix = shift;
    my $current_node = shift; # index of node
    my %visited_nodes;
    while($current_node!=0)
    {
        return 1 if($visited_nodes{$current_node});
        $visited_nodes{$current_node}++;
        my $cnrow = $matrix->[$current_node-1];
        $current_node = $cnrow->[6]; # parent
    }
    # No cycle found.
    return 0;
}
